#include<stdio.h>
void input();
void print();
void calculate();
void sum();
int main(void);

int main(void)

{

    input();

}

void input()

{

    int productcode;
    int productquantity;
    float priceofproduct;
    float subtotal;
    float total;

    total=0.00;
    subtotal=0.00;

    print();
}

void print()

{

    float priceofproduct;
    int productquantity;
    int productcode;

    printf("Enter product code:");
    scanf("%d",&productcode);
    printf("Enter product of price:");
    scanf("%f",&priceofproduct);
    printf("Enter product quantity:");
    scanf("%d",&productquantity);

    calculate();

}

void calculate(float subtotal,float total);

{
    calculate subtotal=priceofproduct*productquantity;
    printf(subtotal);

    float total=subtotal+total;
    printf(total);

    sum();

}

void sum()

{

    float total;

    printf("total is:%d",total);

}

